# Warum `ORDER BY random()` für das Subset zwingend notwendig ist

- **Ohne `ORDER BY` ist die Ausgabe deterministisch, nicht zufällig.**  
  PostgreSQL liefert Zeilen in der Reihenfolge, die am schnellsten ist – physische Speicherung, Index‑Scans, Caches. Diese Reihenfolge kann über viele Abfragen identisch bleiben. `LIMIT 100000` ergibt dann immer dieselbe, nicht zufällige Teilmenge.

- **Der Cache verstärkt das Problem.**  
  Datenblöcke im `shared_buffers`‑Cache werden bevorzugt gelesen. Das führt dazu, dass ein einmal geladenes Subset bei Wiederholung immer wieder aus dem Cache bedient wird – das Gegenteil von Zufall.

- **Die physische Speicheranordnung verzerrt das Subset.**  
  Liegen die Daten chronologisch auf der Platte, bekommt ihr mit `LIMIT` immer die ältesten Zeilen. Euer Modell lernt nur alte Muster und versagt auf neuen Zeiträumen.

- **Reproduzierbarkeit ist nicht garantiert.**  
  Ein `VACUUM`, `ANALYZE` oder neue Daten können den Query‑Plan ändern. Plötzlich ist die Reihenfolge anders – eure Subsets sind nicht mehr nachvollziehbar.

- **Data Leakage durch unkontrollierte Reihenfolge.**  
  Ohne explizite Randomisierung könnt ihr nicht sicherstellen, dass alle Zeitabschnitte gleichmäßig im Subset vertreten sind. Ein nachfolgender chronologischer Split kann dann zu Leakage führen, weil das Subset zeitlich verzerrt ist.

- **`ORDER BY random()` mit `setseed()` ist der einzige korrekte Weg.**  
  Dieser SQL‑Standard‑Befehl garantiert eine echte Zufallsstichprobe. Der Seed macht sie reproduzierbar. Erst danach sortiert ihr das Subset nach Datum – so bleibt die Zufallsauswahl erhalten, aber die Reihenfolge ist chronologisch.